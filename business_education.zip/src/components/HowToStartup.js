import React from 'react';

const HowToStartup = () => (
  <div className="guide-container">
    <h1>How to Startup</h1>
    <p>Ideation...</p>
    <p>Validation...</p>
    <p>Business Plan...</p>
    <p>Building a Team...</p>
    <p>Legal Framework...</p>
    <p>Launch...</p>
    <p>Feedback & Improvement...</p>
    <p>That's all...</p>
  </div>
);

export default HowToStartup;
