// src/components/Reward.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../s4eg.css'; 
const Reward = ({ points }) => {
  const navigate = useNavigate();

  const restartJourney = () => {
    navigate('/'); // Navigate back to home
  };

  return (
    <div className="centered-container">
      <h1>Congratulations!</h1>
      <p>You've completed the Entrepreneurship Journey.</p>
      <p>Total Points: {points}</p>
      <button onClick={restartJourney}>Restart Journey</button>
    </div>
  );
};

export default Reward;


