// src/components/Challenge.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FaStar, FaDollarSign, FaBullhorn, FaLightbulb } from 'react-icons/fa';
import '../s3ch.css'; // Import the CSS file

const questions = [
  {
    id: 1,
    question: 'What is the primary purpose of a business plan?',
    options: [
      { text: 'To raise capital', impact: '70% chance of attracting investors and securing funding.', icon: <FaStar /> },
      { text: 'To set business goals', impact: '60% chance of providing direction and clear objectives.', icon: <FaLightbulb /> },
      { text: 'To manage operations', impact: '55% chance of streamlining processes and improving efficiency.', icon: <FaBullhorn /> },
      { text: 'To attract investors', impact: '65% chance of gaining investor interest and support.', icon: <FaDollarSign /> },
    ],
  },
  {
    id: 2,
    question: 'Which of these is a key component of market research?',
    options: [
      { text: 'Competitor analysis', impact: '70% chance of understanding market position and competitive advantage.', icon: <FaStar /> },
      { text: 'Financial projections', impact: '50% chance of forecasting future revenues and costs.', icon: <FaDollarSign /> },
      { text: 'Product design', impact: '60% chance of developing a product that meets customer needs.', icon: <FaLightbulb /> },
      { text: 'Marketing strategy', impact: '65% chance of effectively reaching target audiences.', icon: <FaBullhorn /> },
    ],
  },
  {
    id: 3,
    question: 'What is the purpose of a SWOT analysis?',
    options: [
      { text: 'To assess financial stability', impact: '50% chance of evaluating financial health and risks.', icon: <FaDollarSign /> },
      { text: 'To identify strengths, weaknesses, opportunities, and threats', impact: '70% chance of providing a comprehensive business overview.', icon: <FaStar /> },
      { text: 'To develop marketing strategies', impact: '60% chance of creating effective promotional campaigns.', icon: <FaLightbulb /> },
      { text: 'To evaluate customer satisfaction', impact: '55% chance of improving products and services based on feedback.', icon: <FaBullhorn /> },
    ],
  },
  {
    id: 4,
    question: 'Which financial statement shows the company’s profitability?',
    options: [
      { text: 'Balance Sheet', impact: '55% chance of providing a snapshot of assets, liabilities, and equity.', icon: <FaBullhorn /> },
      { text: 'Cash Flow Statement', impact: '60% chance of tracking cash inflows and outflows.', icon: <FaDollarSign /> },
      { text: 'Income Statement', impact: '70% chance of showing revenue, expenses, and profit.', icon: <FaStar /> },
      { text: 'Statement of Retained Earnings', impact: '50% chance of indicating how much profit is reinvested in the business.', icon: <FaLightbulb /> },
    ],
  },
  {
    id: 5,
    question: 'What is a business model canvas used for?',
    options: [
      { text: 'To outline the company’s mission and vision', impact: '55% chance of providing a strategic overview.', icon: <FaBullhorn /> },
      { text: 'To map out business strategies and key components', impact: '70% chance of detailing business processes and value propositions.', icon: <FaStar /> },
      { text: 'To forecast future financial performance', impact: '60% chance of predicting revenue streams and cost structures.', icon: <FaDollarSign /> },
      { text: 'To analyze market trends', impact: '50% chance of understanding market dynamics and opportunities.', icon: <FaLightbulb /> },
    ],
  },
];

const Challenge = ({ addPoints }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const questionId = parseInt(id, 10); // Parse the questionId from URL
  const [question, setQuestion] = useState(null);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showImpact, setShowImpact] = useState(false);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      navigate('/login'); // Redirect to login if not logged in
    }

    const currentQuestion = questions.find(q => q.id === questionId);
    setQuestion(currentQuestion);

    if (!currentQuestion) {
      navigate('/404'); // Redirect to a 404 page or show an error if the question doesn't exist
    }
  }, [questionId, navigate]);

  const handleChoice = (option) => {
    if (typeof addPoints === 'function') {
      addPoints(option.points);
    } else {
      console.error('addPoints is not a function');
    }
    setSelectedOption(option);
    setShowImpact(true);

    setTimeout(() => {
      if (questionId < questions.length) {
        navigate(/challenge/${questionId + 1});
      } else {
        // Pass only text and impact to results
        const simplifiedAnswers = selectedOption.map(answer => ({
          text: answer?.text,
          impact: answer?.impact
        }));
        navigate('/results', { state: { selectedAnswers: simplifiedAnswers } });
      }
    }, 3000); // 3 seconds delay
  };

  return (
    <div className="centered-container">
      <h2>Question {questionId}</h2>
      <p>{question ? question.question : 'Loading...'}</p>
      {question ? (
        <div className="options">
          {question.options.map((option, index) => (
            <button 
              key={index} 
              onClick={() => handleChoice(option)}
              className={option-box ${selectedOption === option ? 'selected' : ''}}
            >
              <div className="option-text">
                {option.icon}
                {option.text}
              </div>
              {showImpact && (
                <div className="impact-box">
                  <p>{option.impact}</p>
                </div>
              )}
            </button>
          ))}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default Challenge;