import React from 'react';
import { useLocation } from 'react-router-dom';
import '../styles.css'; // Import the CSS file

const Result = () => {
  const location = useLocation();
  const { points } = location.state || { points: 0 };

  return (
    <div className="centered-container">
      <h2>Results</h2>
      <p>Your total points: {points}</p>
      {/* Additional result details can be added here */}
    </div>
  );
};

export default Result;
