import React from 'react';

const SignsYouAreAnEntrepreneur = () => (
  <div className="guide-container">
    <h1>5 Signs You Are an Entrepreneur</h1>
    <p>1. You are a Risk-Taker...</p>
    <p>2. You Have a Vision...</p>
    <p>3. You are Self-Motivated...</p>
    <p>4. You are Resilient...</p>
    <p>5. You are Always Learning...</p>
  </div>
);

export default SignsYouAreAnEntrepreneur;
