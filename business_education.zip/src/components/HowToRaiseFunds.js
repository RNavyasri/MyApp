import React from 'react';

const HowToRaiseFunds = () => (
  <div className="guide-container">
    <h1>How to Raise Funds for Your Startup</h1>
    <p>1. Bootstrapping...</p>
    <p>2. Friends and Family...</p>
    <p>3. Angel Investors...</p>
    <p>4. Venture Capital...</p>
    <p>5. Crowdfunding...</p>
  </div>
);

export default HowToRaiseFunds;
