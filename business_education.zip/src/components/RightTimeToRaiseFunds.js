import React from 'react';

const RightTimeToRaiseFunds = () => (
  <div className="guide-container">
    <h1>Right Time to Raise Funds</h1>
    <p>1. Validated Idea...</p>
    <p>2. Proven Business Model...</p>
    <p>3. Growing Customer Base...</p>
    <p>4. Clear Financial Projections...</p>
    <p>5. Strong Team...</p>
  </div>
);

export default RightTimeToRaiseFunds;
